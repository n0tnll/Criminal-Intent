package com.shv.android.criminal_intent

import java.util.*

data class Crime(val id: UUID = UUID.randomUUID(),
                 var name: String = "",
                 var date: Date = Date(),
                 var isSolved: Boolean = false)
